FileSystem.mkpath(Paths.installPath);
FileSystem.install("bin", Paths.installPath + "/bin");
FileSystem.install("doc", Paths.installPath + "/doc");

