FileSystem.remove(Paths.installPath + "/bin/package1program");
FileSystem.remove(Paths.installPath + "/bin/package1program2");
FileSystem.remove(Paths.installPath + "/doc/package1.doc");
FileSystem.remove(Paths.installPath + "/doc/package1");
