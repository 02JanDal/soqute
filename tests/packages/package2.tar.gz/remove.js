FileSystem.remove(Paths.installPath + "/bin/package2program");
FileSystem.remove(Paths.installPath + "/bin/package2program2");
FileSystem.remove(Paths.installPath + "/doc/package2.doc");
FileSystem.remove(Paths.installPath + "/doc/package2");
